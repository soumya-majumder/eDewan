import React, { useState } from 'react'
import CustomerList from '../../views/customers/CustomerList.js'

import {
  CButton,
  CCol,
  CRow,
  CContainer,
  CFormInput,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { freeSet } from '@coreui/icons'

const handleChange = function (item) {
  console.log('Item : ' + item)
}

const guarantorSelectHandler = function (item) {
  console.log('Item : ' + item)
}

const CustomersLovModal = (props) => {
  const placeholder = 'Select '+(props.target?props.target:'Customer')
  const [visible, setVisible] = useState(false)
  return (
    <>
      <div className="input-group">
        <CFormInput type="text" id="guarantorId" placeholder={placeholder} />
        <CButton
          onClick={() => setVisible(!visible)}
          className="btn btn-outline-secondary"
          type="button"
          id="button-addon2"
        >
          <CIcon icon={freeSet.cilSearch}></CIcon>
        </CButton>
      </div>
      <CModal visible={visible} onClose={() => setVisible(false)}>
        <CModalHeader onClose={() => setVisible(false)}>
          <CModalTitle>Select Guarantor</CModalTitle>
        </CModalHeader>
        <CustomerList hideAction="true" />
        <CModalFooter>
          <CButton color="secondary" onClick={() => setVisible(false)}>
            Close
          </CButton>
        </CModalFooter>
      </CModal>
    </>
  )
}

export default CustomersLovModal
