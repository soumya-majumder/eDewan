import React from 'react'
import { useLocation } from 'react-router-dom'
import routes from '../routes'

import {
    CCol,
} from '@coreui/react'

const HeaderName = () => {
    const currentLocation = useLocation().pathname

    const getRouteName = (pathname, routes) => {
        const currentRoute = routes.find((route) => route.path === pathname)
        return currentRoute ? currentRoute.name : false
    }

    const getPageName = (location) => {
        const routeName = getRouteName(location, routes)
        return routeName
    }

    var headerName = getPageName(currentLocation)

    return (
        <CCol md={8}>
            <div className="row d-flex justify-content-between">
                <h4 className="card-title col-4">{headerName}</h4>
            </div>
        </CCol>
    )
}

export default React.memo(HeaderName)
