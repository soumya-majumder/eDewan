import React from 'react'
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css'
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css'
import AccountList from './AccountList.js'
import HeaderName from '../../components/HeaderName.js'

import {
  CButton,
  CCol,
  CContainer,
  CHeaderDivider,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { freeSet } from '@coreui/icons'

const Customers = () => {
  return (
    <>
      <HeaderName />
      <CHeaderDivider />
      <AccountList />
    </>
  )
}

export default Customers
