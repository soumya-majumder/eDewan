import React, { useState } from 'react'
import DataTable from 'react-data-table-component'
import data from '../../assets/data.json'

import {
  CButton,
  CCard,
  CCardGroup,
  CCardBody,
  CCol,
  CRow,
  CContainer,
  CForm,
  CFormLabel,
  CFormInput,
  CDataTable,
  CBadge,
} from '@coreui/react'
const columns = [
  {
    name: 'Name',
    selector: 'name',
    sortable: true,
  },
  {
    name: 'Phone',
    selector: 'phone',
    sortable: true,
  },
  {
    name: 'Email',
    selector: 'email',
    sortable: true,
  },
  {
    name: 'DOB',
    selector: 'dob',
  },
]

const AccountList = () => {
  const updateData = function(searchDiv){
    if(searchDiv != undefined && searchDiv.currentTarget != undefined){
      console.log(searchDiv.currentTarget.value)
      setFilteredData(data.filter(row => (row.name.toLowerCase().includes(searchDiv.currentTarget.value.toLowerCase())
        || row.phone.toLowerCase().includes(searchDiv.currentTarget.value.toLowerCase())
        || row.email.toLowerCase().includes(searchDiv.currentTarget.value.toLowerCase())))
      )
    } else {
      setFilteredData(data)
    }
  }
  const highlightText = (text, highlight) => {
    // Split text on highlight term, include term itself into parts, ignore case
    const parts = text.split(new RegExp(`(${highlight})`, 'gi'));
    return <span>{parts.map(part => part.toLowerCase() === highlight.toLowerCase() ? <b>{part}</b> : part)}</span>;
  }
  
  let [filteredData, setFilteredData] = useState(data);

  return (
    <>
      <div className="d-flex flex-row">
        <CContainer>
          <CRow className="justify-content-center">
            <CCol md={12}>
              <CCardGroup>
                <CCard className="">
                  <CCardBody>
                    <div className="row">
                      <div className="col-12 p-2">
                        <CFormInput onChange={updateData} type="text" id="custId" placeholder="Search for Customer ID, Account No, Name or Phone No..." />
                      </div>
                    </div>
                  </CCardBody>
                </CCard>
              </CCardGroup>
            </CCol>
          </CRow>
        </CContainer>
      </div>
      <div className="d-flex flex-row">
        <CContainer>
          <CRow className="justify-content-center">
            <CCol md={12}>
              <div className="App">
                <DataTable
                  columns={columns}
                  data={filteredData}
                  pagination
                  highlightOnHover
                />
              </div>
            </CCol>
          </CRow>
        </CContainer>
      </div>
    </>
  )
}

export default AccountList
