import React, { useEffect } from 'react'

import {
    CButton,
    CFormCheck,
    CCard,
    CCardGroup,
    CCardBody,
    CCol,
    CRow,
    CContainer,
    CForm,
    CFormLabel,
    CFormInput,
    CInputGroup,
    CInputGroupText,
    CCardFooter
} from '@coreui/react'
import { CountryDropdown, RegionDropdown } from 'react-indian-state-region-selector';
import StateCityDropDown from './StateCity'
import * as ReactDOM from 'react-dom/client'
import CIcon from '@coreui/icons-react'
import { freeSet } from '@coreui/icons'
import CustomerDetails from './CustomerDetails.js'
import CustomersLovModal from '../../components/lov/CustomersLovModal.js'
import HeaderName from '../../components/HeaderName.js'

const GuarantorDetails = (props) => {
    const readonly = props.readonly
    return (
        <>
        <div className='row'>
            <div className="col-4 py-3" id="addGuarantor">
                <CustomersLovModal target="Guarantor" />
            </div>
            <CustomerDetails readonly={readonly}/>
        </div>
        </>
    )
}

export default GuarantorDetails
