import React, { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom';

import {
	CButton,
	CFormCheck,
	CCard,
	CCardGroup,
	CCardBody,
	CCol,
	CRow,
	CContainer,
	CForm,
	CFormLabel,
	CFormInput,
	CInputGroup,
	CInputGroupText,
	CCardFooter,
	CAccordion,
	CAccordionItem,
	CAccordionHeader,
	CAccordionBody,
	CFormSwitch
} from '@coreui/react'
import { CountryDropdown, RegionDropdown } from 'react-indian-state-region-selector';
import StateCityDropDown from './StateCity'
import * as ReactDOM from 'react-dom/client'
import CIcon from '@coreui/icons-react'
import { freeSet } from '@coreui/icons'
import CustomersLovModal from '../../components/lov/CustomersLovModal.js'
import CustomerDetails from './CustomerDetails.js'
import GuarantorDetails from './GuarantorDetails.js'
import HeaderName from '../../components/HeaderName.js'



const AddCustomer = (props) => {
	const { state } = useLocation();
	let [guarantorNeeded, setGuarantorNeeded] = useState(false)

	const guarantorNeededChange = (val) => {
		setGuarantorNeeded(val.currentTarget.checked)
	}
	const ShowHideGuarantorDetails = (props) => {
		if (props.guarantorNeeded) {
			return (
				<CAccordionItem itemKey={4}>
					<CAccordionHeader>Guarantor Details</CAccordionHeader>
					<CAccordionBody>
						<GuarantorDetails readonly={false}/>
					</CAccordionBody>
				</CAccordionItem>
			)
		} else {
			return ''
		}
	}
	return (
		<>
			<HeaderName />
			<div className="d-flex flex-row">
				<CContainer>
					<CRow className="justify-content-center">
						<CCard className="">
							<CCardBody>
								<CForm>
									<CAccordion activeItemKey={1}>
										<CAccordionItem itemKey={1}>
											<CAccordionHeader>Customer Details</CAccordionHeader>
											<CAccordionBody>
												<CustomerDetails />
											</CAccordionBody>
										</CAccordionItem>
										<CAccordionItem itemKey={2}>
											<CAccordionHeader>Account Details</CAccordionHeader>
											<CAccordionBody>
												<h6 className="card-title col-12" style={{ borderBottom: "solid #b1b7c1 1px", paddingBottom: "10px" }}>Account</h6>
												<div className="row">
													<div className="col-4 p-2">
														<CFormLabel htmlFor="initialFunding">Initial Funding</CFormLabel>
														<CInputGroup>
															<CInputGroupText id="basic-addon1">Rs.</CInputGroupText>
															<CFormInput type="text" id="initialFunding" />
														</CInputGroup>
													</div>
													<div className="col-4 p-2 px-4" id="addGuarantor">
														<CFormLabel></CFormLabel>
														<CFormSwitch onChange={guarantorNeededChange} className='pt-3' type="checkbox" id="guarantorCheck" label="Add a guarantor" />
													</div>
												</div>
											</CAccordionBody>
										</CAccordionItem>
										<ShowHideGuarantorDetails guarantorNeeded={guarantorNeeded} />
									</CAccordion>
								</CForm>
							</CCardBody>
							<CCardFooter>
								<CCol xs={12}>
									<div className='d-grid gap-2 d-md-flex justify-content-md-end'>
										<CButton type="submit">Submit</CButton>
										<CButton color="danger">Clear</CButton>
									</div>
								</CCol>
							</CCardFooter>
						</CCard>
					</CRow>
				</CContainer>
			</div>
		</>
	)
}

export default AddCustomer
