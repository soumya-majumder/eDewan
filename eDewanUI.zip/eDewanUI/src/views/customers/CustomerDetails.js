import React from 'react'

import {
    CFormLabel,
    CFormInput,
    CInputGroup,
    CDropdown,
    CDropdownToggle,
    CDropdownMenu,
    CDropdownItem,
} from '@coreui/react'
import StateCityDropDown from './StateCity'

const CustomerDetails = (props) => {
    const readonly = props.readonly
    return (
        <>
            <h6 className="card-title col-12" style={{ borderBottom: "solid #b1b7c1 1px", paddingBottom: "10px" }}>Personal Details</h6>
            <div className="row">
                <div className="col-4 p-2">
                    <CFormLabel htmlFor="fName">First Name</CFormLabel>
                    <CFormInput type="text" id="fName" disabled={readonly}/>
                </div>
                <div className="col-4 p-2">
                    <CFormLabel htmlFor="mName">Middle Name</CFormLabel>
                    <CFormInput type="text" id="mName" />
                </div>
                <div className="col-4 p-2">
                    <CFormLabel htmlFor="lName">Last Name</CFormLabel>
                    <CFormInput type="text" id="lName" />
                </div>
            </div>
            <div className="row">
                <div className="col-4 p-2">
                    <CFormLabel htmlFor="phnNo">Phone Number</CFormLabel>
                    <CFormInput type="text" id="phnNo" />
                </div>
                <div className="col-4 p-2">
                    <CFormLabel htmlFor="emailId">Email ID</CFormLabel>
                    <CFormInput type="email" id="emailId" />
                </div>
                <div className="col-4 p-2">
                    <CFormLabel htmlFor="idProof">ID Proof</CFormLabel>
                    <CInputGroup>
                        <CDropdown variant="input-group">
                            <CDropdownToggle color="secondary" variant="outline">ID Type</CDropdownToggle>
                            <CDropdownMenu>
                                <CDropdownItem href="#">Aadhar Card</CDropdownItem>
                                <CDropdownItem href="#">Pan Card</CDropdownItem>
                                <CDropdownItem href="#">Voter Card</CDropdownItem>
                                <CDropdownItem href="#">Driving License</CDropdownItem>
                            </CDropdownMenu>
                        </CDropdown>
                        <CFormInput type="text" id="idProofNo" />
                    </CInputGroup>
                </div>
            </div>
            <div className="row">
                <div className="col-4 p-2">
                    <CFormLabel htmlFor="fName">Upload ID Proof</CFormLabel>
                    <CFormInput type="file" id="idImg" />
                </div>
                <div className="col-4 p-2">
                    <CFormLabel htmlFor="mName">Upload Photo</CFormLabel>
                    <CFormInput type="file" id="custPhoto" />
                </div>
            </div>

            <h6 className="card-title col-12" style={{ borderBottom: "solid #b1b7c1 1px", paddingBottom: "10px" }}>Address Details</h6>
            <StateCityDropDown />
            <div className="row">
                <div className="col-4 p-2">
                    <CFormLabel htmlFor="zipCode">Pin Code</CFormLabel>
                    <CFormInput type="text" id="zipCode" />
                </div>
                <div className="col-4 p-2">
                    <CFormLabel htmlFor="locality">Locality</CFormLabel>
                    <CFormInput type="text" id="locality" />
                </div>
            </div>
        </>
    )
}

export default CustomerDetails
