import React, { useEffect } from 'react'
import { useFormik } from "formik";
import Select from "react-select";
import { Country, State, City } from "country-state-city";
import { CFormLabel } from '@coreui/react'

export default function StateCity() {
  const addressFromik = useFormik({
    initialValues: {
      country: Country.getCountryByCode('IN'),
      state: State.getStateByCodeAndCountry('WB', 'IN'),
      city: City.getCitiesOfState('IN','WB').filter((city) => city.name == 'Medinipur')[0]
    },
    onSubmit: (values) => console.log(JSON.stringify(values))
  });

  const countries = Country.getAllCountries();

  const updatedCountries = countries.map((country) => ({
    label: country.name,
    value: country.id,
    ...country
  }));
  const updatedStates = (countryId) =>
    State
      .getStatesOfCountry(countryId)
      .map((state) => ({ label: state.name, value: state.id, ...state }));
  const updatedCities = (countryId,stateId) =>
    City
      .getCitiesOfState(countryId,stateId)
      .map((city) => ({ label: city.name, value: city.id, ...city }));

  const { values, handleSubmit, setFieldValue, setValues } = addressFromik;

  useEffect(() => { }, [values]);

  return (
    <div className="StateCity">
      <div className="row">
        <div className="col-4 p-2">
          <CFormLabel htmlFor="country">Country</CFormLabel>
          <Select
            id="country"
            name="country"
            label="country"
            options={updatedCountries}
            value={values.country}
            onChange={(value) => {
              setValues({ country: value, state: null, city: null }, false);
            }}
          />
        </div>
        <div className="col-4 p-2">
          <CFormLabel htmlFor="state">State</CFormLabel>
          <Select
            id="state"
            name="state"
            options={updatedStates(values.country ? values.country.isoCode : null)}
            value={values.state}
            onChange={(value) => {
              console.log("Value : "+value.isoCode);
              setValues({ state: value, city: null }, false);
            }}
          />
        </div>
        <div className="col-4 p-2">
          <CFormLabel htmlFor="city">City</CFormLabel>
          <Select
            id="city"
            name="city"
            options={updatedCities(values.state ? values.state.countryCode : null,values.state ? values.state.isoCode : null)}
            value={values.city}
            onChange={(value) => setFieldValue("city", value)}
          />
        </div>
      </div>
    </div>
  );
}
