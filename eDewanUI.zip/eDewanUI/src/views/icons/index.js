import CoreUIIcons from './coreui-icons'
import Flags from './flags'
import Brands from './brands'

export { CoreUIIcons, Flags, Brands }
