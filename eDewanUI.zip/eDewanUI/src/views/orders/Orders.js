import React from 'react'
import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css'
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css'
import OrderList from './OrderList.js'
import HeaderName from '../../components/HeaderName.js'

import {
  CButton,
  CCol,
  CContainer,
  CHeaderDivider,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { freeSet } from '@coreui/icons'

const Orders = () => {
  return (
    <>
      <HeaderName />
      <div className="d-flex flex-row">
        <CContainer>
            <CCol md={12}>
              <div className="row d-flex justify-content-between" style={{ float: "right", paddingBottom: "20px", marginTop: "-30px" }}>
                  <CButton id="addCustomer" type="button" href="#/orders/neworder">
                    Add New Order
                    <CIcon style={{ paddingLeft: "5px" }} size={"lg"} icon={freeSet.cilUserPlus}></CIcon >
                  </CButton>
              </div>
            </CCol>
        </CContainer>
      </div>
      <CHeaderDivider />
      <OrderList />
    </>
  )
}

export default Orders
