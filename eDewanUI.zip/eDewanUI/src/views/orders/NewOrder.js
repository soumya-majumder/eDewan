import React, { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom';
import DatePicker from "react-datepicker";
import Select from "react-select";
import CIcon from '@coreui/icons-react'
import { freeSet } from '@coreui/icons'

import {
    CButton,
    CFormCheck,
    CCard,
    CCardGroup,
    CCardBody,
    CCol,
    CRow,
    CContainer,
    CForm,
    CFormLabel,
    CFormInput,
    CInputGroup,
    CInputGroupText,
    CCardFooter,
    CAccordion,
    CAccordionItem,
    CAccordionHeader,
    CAccordionBody,
    CFormSwitch,
    CDropdown,
    CDropdownMenu,
    CDropdownItem,
    CDropdownToggle
} from '@coreui/react'
import CustomersLovModal from '../../components/lov/CustomersLovModal.js'
import HeaderName from '../../components/HeaderName.js'
import 'react-datepicker/dist/react-datepicker.css'



const AddCustomer = (props) => {
    const { state } = useLocation();
    const [startDate, setStartDate] = useState(new Date())
    const [orderStatus, setOrderStatus] = useState({label:"New",value:"new"})
    return (
        <>
            <HeaderName />
            <div className="d-flex flex-row">
                <CContainer>
                    <CRow className="justify-content-center">
                        <CCard className="">
                            <CCardBody>
                                <CForm>
                                    <h6 className="card-title col-12" style={{ borderBottom: "solid #b1b7c1 1px", paddingBottom: "10px" }}>Customer Details</h6>
                                    <div className="row">
                                        <div className="col-4 p-2">
                                            <CFormLabel htmlFor="orderCustomerId">Select Customer</CFormLabel>
                                            <CustomersLovModal target="Customer" />
                                        </div>
                                        <div className="col-4 p-2">
                                            <CFormLabel htmlFor="orderCustomerName">Customer Name</CFormLabel>
                                            <CFormInput type="text" id="orderCustomerName" disabled />
                                        </div>
                                        <div className="col-4 p-2">
                                            <CFormLabel htmlFor="orderCustomerPhone">Customer Phone</CFormLabel>
                                            <CFormInput type="text" id="orderCustomerPhone" />
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-4 p-2">
                                            <CFormLabel htmlFor="orderCustomerId">Customer Account Balance</CFormLabel>
                                            <CInputGroup>
                                                <CInputGroupText id="basic-addon1">Rs.</CInputGroupText>
                                                <CFormInput type="text" id="initialFunding" value={0} disabled/>
                                            </CInputGroup>
                                        </div>
                                    </div>
                                    <h6 className="card-title col-12" style={{ borderBottom: "solid #b1b7c1 1px", paddingBottom: "10px" }}>Order Details</h6>
                                    <div className="row">
                                        <div className="col-4 p-2">
                                            <CFormLabel htmlFor="orderId">Order Id</CFormLabel>
                                            <CFormInput type="text" id="orderId" disabled />
                                        </div>
                                        <div className="col-4 p-2">
                                            <CFormLabel htmlFor="orderStatus">Status</CFormLabel>
                                            <Select
                                                id="name"
                                                name="name"
                                                options={[{label:'New',value:'new'},
                                                            {label:'Work In Progress',value:'wip'},
                                                            {label:'Completed',value:'completed'}]}
                                                value={orderStatus.value}
                                                onChange={ (value) => {setOrderStatus(value.value)}}
                                            />
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-4 p-2">
                                            <CFormLabel htmlFor="orderDate">Order Date</CFormLabel>
                                            <DatePicker className="form-control" selected={startDate} onChange={(date) => setStartDate(date)} />
                                        </div>
                                        <div className="col-4 p-2">
                                            <CFormLabel htmlFor="orderWorkStartDate">Work Start Date</CFormLabel>
                                            <DatePicker className="form-control" onChange={(date) => setStartDate(date)} />
                                        </div>
                                        <div className="col-4 p-2">
                                            <CFormLabel htmlFor="initialFunding">Order Delivery Date</CFormLabel>
                                            <DatePicker className="form-control" onChange={(date) => setStartDate(date)} />
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-4 p-2">
                                            <CFormLabel htmlFor="orderTotalCost">Total Cost</CFormLabel>
                                            <CInputGroup>
                                                <CInputGroupText id="basic-addon1">Rs.</CInputGroupText>
                                                <CFormInput type="number" id="orderTotalCost" />
                                            </CInputGroup>
                                        </div>
                                        <div className="col-4 p-2">
                                            <CFormLabel htmlFor="orderAdvanceAmount">Advance Amount</CFormLabel>
                                            <CInputGroup>
                                                <CInputGroupText id="basic-addon1">Rs.</CInputGroupText>
                                                <CFormInput type="number" id="orderAdvanceAmount" />
                                            </CInputGroup>
                                        </div>
                                        <div className="col-4 p-2">
                                            <CFormLabel htmlFor="orderDueAmount">Due Amount</CFormLabel>
                                            <CInputGroup>
                                                <CInputGroupText id="basic-addon1">Rs.</CInputGroupText>
                                                <CFormInput type="number" id="orderDueAmount" />
                                            </CInputGroup>
                                        </div>
                                    </div>
                                </CForm>
                            </CCardBody>
                            <CCardFooter>
                                <CCol xs={12}>
                                    <div className='d-grid gap-2 d-md-flex justify-content-md-end'>
                                        <CButton type="submit">Submit</CButton>
                                        <CButton color="danger">Clear</CButton>
                                    </div>
                                </CCol>
                            </CCardFooter>
                        </CCard>
                    </CRow>
                </CContainer>
            </div>
        </>
    )
}

export default AddCustomer
